
package Code;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Invoice{
    
    
    private List<Food> items = new ArrayList<>();

    public void addItem(Food foodItem) {
        items.add(foodItem);
    }
    
    public List<Food> getItems() {
        return items;
    }

    public double calculateTotal() {
        double total = 0;
        for (Food item : items) {  
            total += item.getPrice();
        }
        return total;
    }
 public void saveToFile() {
   
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("Invoice.txt",true))) {
            for (Food item : items) {
              
                writer.write(item.toString()+"\n\n");
                writer.newLine(); 
            }
        } catch (IOException e) {
        }
    }  
}


