
package Code;

public interface Item {
    double getPrice();
    String getName();
    String getDescription();
}
