package Code;

import java.io.FileWriter;
import java.io.IOException;

public class Main {

    public static void main(String[] args) {
        
        Inventory in = new Inventory();
        
        Food specialPizza = new Food("Zoro's Special pizza", 750.56, "Tomato sauce, Mozzarella, Eggplants, Artichokes, Garlic, Basil");
        Food pepperoniPizza = new Food("Pepperoni Pizza" , 550.21,"Pepperoni");
        Food bbqpizza = new Food("BBQ Pizza", 450.50, "Barbique chicken, Mozzarella, Basil, Eggplants");
        
        Food luffyBurger = new Food("Luffy's Naga Burger" , 450.76 , "Extra Spicy with chicken, basil, tomato");
        Food junior = new Food("Junior Burger" , 250.45 , "Junior Size with extra dippings");
        Food patty = new Food("3 Patty Burger" , 760.76, "3 Layers of spicy chicken with gravy cheese");
        
        Food chillidog = new Food("Chilli Hot Dog", 350.34, "A regural hot dog with chilli chicken");
        Food  chicago = new Food("Chicago-Style Hot Dog", 430.34, "It's chicago-style babes");
        
        Food fsmall = new Food("French Fry Large", 150.10, "It's smaller :)");
        Food flarge = new Food("French fry Large", 230.10, "Bigger is better");

        in.addItem(specialPizza);
        in.addItem(pepperoniPizza);
        in.addItem(bbqpizza);
        in.addItem(luffyBurger);
        in.addItem(junior);
        in.addItem(patty);
        in.addItem(chillidog);
        in.addItem(chicago);
        in.addItem(flarge);
        in.addItem(fsmall);
        
        try (FileWriter fw = new FileWriter("Inventory.txt")) {
            for (Food food : in) {
                fw.write(food.toString());
            }

        } catch (IOException e) {
        }
        
    }
}
