
package Code;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

public class Inventory implements Iterable<Food>  {

    private ArrayList<Food> item;

    public Inventory() {
        item = new ArrayList<>();
    }
    public void addItem(Food food) {
        item.add(food);
    }
    @Override
     public Iterator<Food> iterator() {
        return item.iterator();
    }
}
